# W1.1 - Tham số bring-up

- Chân GPIO dùng để tag task (blink + đo logic analyzer): **GPIOB pin 0**.
- Chu kỳ blink task A: **379 ms**, task B: **711 ms**.
- Xung xác minh 72 MHz xuất ra từ TIM ở 1 kHz; sai số cho phép: **282 ppm** (~±0.282 Hz quanh 1000 Hz).
- Đo tần số thực tế bằng logic analyzer và ghi vào SETUP.md/REPORT.md;
  vượt ngưỡng trên nghĩa là cấu hình PLL/flash-latency sai.
