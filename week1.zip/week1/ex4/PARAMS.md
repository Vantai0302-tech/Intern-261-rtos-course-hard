# W1.4 - Tham số thí nghiệm phân mảnh heap + ngân sách RAM

| # | Size (bytes) |
|---|---|
| 0 | 56 |
| 1 | 56 |
| 2 | 40 |
| 3 | 256 |
| 4 | 200 |
| 5 | 320 |
| 6 | 160 |
| 7 | 128 |

- Thứ tự free (theo chỉ số cấp phát ở trên): **[2, 3, 6, 1, 4, 7, 0, 5]**.
- Lặp lại toàn bộ chu trình cấp phát/giải phóng **3 lần**,
  ghi `xPortGetFreeHeapSize()` và `xPortGetMinimumEverFreeHeapSize()`
  sau mỗi bước vào log.
- Sau khi chuyển sang `configSUPPORT_DYNAMIC_ALLOCATION=0`: sai số cho
  phép giữa bảng RAM tự tính và file `.map` là **255 bytes**.
- Giải thích vì sao thứ tự free ở trên gây phân mảnh (hay không) dựa
  trên thuật toán coalescing của heap_4 (best-fit theo địa chỉ).
