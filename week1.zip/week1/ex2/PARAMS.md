# W1.2 - Tham số tracer / Gantt

- Sai số cho phép khi đối chiếu Gantt từ tracer với ảnh logic analyzer: **13 us**.
- Jitter context-switch tối đa chấp nhận được ở -O2 (max - min): **309 chu kỳ**.
- Vượt quá hai ngưỡng trên coi là KHÔNG đạt tiêu chí Output của W1.2;
  giải thích định lượng nguyên nhân (tick, context switch, ISR) trong REPORT.md.
