# W1.3 - Tham số phân tích lập lịch (RTA)

| Task | T (ms) | D (ms) | C busy-wait (us) |
|---|---|---|---|
| τ0 | 40 | 40 | 7485 |
| τ1 | 80 | 80 | 10029 |
| τ2 | 120 | 120 | 19288 |
| τ3 | 150 | 150 | 20668 |

Ghi chú:
- Đây là bộ 4 task với deadline ngầm định D_i = T_i.
- Đề KHÔNG tiết lộ tập này có schedulable hay không theo RM. Sinh viên phải
  tự tính utilization, so với giới hạn Liu-Layland, rồi chạy RTA bằng tay để
  kết luận chắc chắn (LL chỉ là điều kiện đủ, không phải cần).
- Nếu kết luận KHÔNG schedulable: phải đề xuất cách sửa (đổi T, giảm C,
  đổi priority...) và chứng minh lại bằng RTA.
- C sinh ra bằng vòng lặp busy-wait hiệu chỉnh qua DWT->CYCCNT ở 72 MHz;
  tự quy đổi us -> số chu kỳ cần đếm.
